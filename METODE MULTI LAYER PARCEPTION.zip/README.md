# PythonMLP
Basic python-numpy implementation of Multi-Layer Perceptron and Backpropagation with regularization.
The file main.py shows how to use the MLP implementation training a simple net to perform the XOR operation:
<img src="https://github.com/lopeLH/PythonMLP/blob/master/figure_1.png"  width=400 height=300 />
